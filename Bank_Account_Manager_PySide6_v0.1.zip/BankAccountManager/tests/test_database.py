
from bank_account_manager.database import Database
from bank_account_manager.models import Account

def test_crud(tmp_path):
    db=Database(tmp_path/"test.db")
    # The test database is seeded by default; add a distinct account.
    a=Account(holder="Test User",account_no="999999",ifsc="TEST0001",bank="Test Bank",branch="Test Branch")
    aid=db.add(a)
    got=db.get(aid)
    assert got.holder=="Test User"
    got.notes="Updated"
    db.update(got)
    assert db.get(aid).notes=="Updated"
    db.delete(aid)
    assert db.get(aid) is None
    db.close()
