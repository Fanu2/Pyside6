
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter


def export_xlsx(accounts, output, title="Bank Account Register"):
    output = Path(output)
    wb = Workbook()
    ws = wb.active
    ws.title = "Accounts"

    navy, blue, pale, white = "17365D", "2F75B5", "F5F9FC", "FFFFFF"

    ws.merge_cells("A1:J1")
    ws["A1"] = title
    ws["A1"].font = Font(size=18, bold=True, color=white)
    ws["A1"].fill = PatternFill("solid", fgColor=navy)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 32

    headers = ["Account Holder","A/C No.","IFSC / Identifier","Bank","Branch",
               "Account Type","Nickname","Notes","Active","ID"]
    for c, h in enumerate(headers, 1):
        cell = ws.cell(3,c,h)
        cell.font = Font(bold=True,color=white)
        cell.fill = PatternFill("solid",fgColor=blue)
        cell.alignment = Alignment(horizontal="center")

    for r, a in enumerate(accounts,4):
        values = [a.holder,a.account_no,a.ifsc,a.bank,a.branch,a.account_type,
                  a.nickname,a.notes,"Yes" if a.active else "No",a.id]
        for c,v in enumerate(values,1):
            cell=ws.cell(r,c,v)
            cell.fill=PatternFill("solid",fgColor=white if r%2 else pale)
            cell.alignment=Alignment(vertical="center",wrap_text=True)
        ws.cell(r,2).number_format="@"
        ws.cell(r,3).number_format="@"

    if accounts:
        ref=f"A3:J{3+len(accounts)}"
        tab=Table(displayName="AccountsExport",ref=ref)
        tab.tableStyleInfo=TableStyleInfo(name="TableStyleMedium2",showRowStripes=False)
        ws.add_table(tab)

    widths=[28,22,22,28,25,16,20,35,10,8]
    for i,w in enumerate(widths,1):
        ws.column_dimensions[get_column_letter(i)].width=w
    ws.freeze_panes="A4"
    ws.sheet_view.showGridLines=False
    ws.auto_filter.ref=f"A3:J{max(3,3+len(accounts))}"
    ws.page_setup.orientation="landscape"
    ws.page_setup.fitToWidth=1
    ws.sheet_properties.pageSetUpPr.fitToPage=True

    summary=wb.create_sheet("Bank Summary")
    summary.sheet_view.showGridLines=False
    summary.append(["Bank","Accounts","Holders","Branches"])
    for cell in summary[1]:
        cell.font=Font(bold=True,color=white)
        cell.fill=PatternFill("solid",fgColor=blue)
        cell.alignment=Alignment(horizontal="center")
    banks={}
    for a in accounts:
        b=banks.setdefault(a.bank,{"accounts":0,"holders":set(),"branches":set()})
        b["accounts"]+=1; b["holders"].add(a.holder); b["branches"].add(a.branch)
    for bank,info in sorted(banks.items()):
        summary.append([bank,info["accounts"],len(info["holders"]),len(info["branches"])])
    for col,w in {"A":30,"B":14,"C":14,"D":14}.items():
        summary.column_dimensions[col].width=w
    summary.freeze_panes="A2"

    wb.save(output)
    return output


def export_csv(accounts, output):
    import csv
    output=Path(output)
    with output.open("w",newline="",encoding="utf-8-sig") as f:
        writer=csv.writer(f)
        writer.writerow(["Account Holder","A/C No.","IFSC","Bank","Branch","Account Type","Nickname","Notes","Active"])
        for a in accounts:
            writer.writerow([a.holder,a.account_no,a.ifsc,a.bank,a.branch,a.account_type,
                             a.nickname,a.notes,"Yes" if a.active else "No"])
    return output
