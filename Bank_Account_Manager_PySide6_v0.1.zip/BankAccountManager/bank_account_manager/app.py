
import sys
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,
    QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QHeaderView,
    QMessageBox,QFileDialog,QFrame,QSplitter,QGroupBox,QFormLayout,QComboBox
)
from .database import Database
from .dialogs import AccountDialog
from .exporter import export_xlsx, export_csv

STYLE="""
QMainWindow,QWidget { background:#11151b; color:#e8edf5; font-family:"Segoe UI","Noto Sans",sans-serif; }
QFrame#card,QGroupBox { background:#191e27; border:1px solid #2b323e; border-radius:10px; }
QLabel#title { font-size:23px; font-weight:700; }
QLabel#muted { color:#8d98aa; }
QLineEdit,QComboBox { background:#14181e; border:1px solid #384151; border-radius:7px; padding:8px; }
QPushButton { background:#252c38; border:1px solid #384151; border-radius:7px; padding:8px 12px; }
QPushButton:hover { background:#303948; }
QPushButton#primary { background:#5d6fff; border:0; font-weight:700; }
QTableWidget { background:#14181e; border:1px solid #2b323e; border-radius:8px; gridline-color:#252c35; }
QTableWidget::item { padding:7px; }
QTableWidget::item:selected { background:#303b68; }
QHeaderView::section { background:#252c38; color:#e8edf5; padding:8px; border:0; font-weight:700; }
"""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Bank Account Manager")
        self.resize(1400,820)
        self.db=Database()
        self.build()
        self.menu()
        self.refresh()

    def build(self):
        root=QWidget(); self.setCentralWidget(root); main=QVBoxLayout(root)

        header=QFrame(); header.setObjectName("card")
        h=QHBoxLayout(header)
        titles=QVBoxLayout()
        t=QLabel("Bank Account Manager"); t.setObjectName("title")
        s=QLabel("Secure local register • CRUD • bank-wise reporting • Excel / CSV export"); s.setObjectName("muted")
        titles.addWidget(t); titles.addWidget(s); h.addLayout(titles); h.addStretch()
        self.status=QLabel("Ready"); h.addWidget(self.status)
        main.addWidget(header)

        stats=QHBoxLayout()
        self.stat_total=self.stat_card("TOTAL ACCOUNTS")
        self.stat_banks=self.stat_card("BANKS")
        self.stat_holders=self.stat_card("HOLDERS")
        self.stat_active=self.stat_card("ACTIVE")
        for x in (self.stat_total,self.stat_banks,self.stat_holders,self.stat_active): stats.addWidget(x)
        main.addLayout(stats)

        tools=QFrame(); tools.setObjectName("card"); tl=QHBoxLayout(tools)
        self.search=QLineEdit(); self.search.setPlaceholderText("🔎  Search holder, account, IFSC, bank, branch…")
        self.search.textChanged.connect(self.refresh); tl.addWidget(self.search,1)
        self.bank_filter=QComboBox(); self.bank_filter.addItem("All banks"); self.bank_filter.currentTextChanged.connect(self.refresh)
        tl.addWidget(self.bank_filter)
        add=QPushButton("＋ New Account"); add.setObjectName("primary"); add.clicked.connect(self.add_account); tl.addWidget(add)
        edit=QPushButton("Edit"); edit.clicked.connect(self.edit_account); tl.addWidget(edit)
        delete=QPushButton("Delete"); delete.clicked.connect(self.delete_account); tl.addWidget(delete)
        main.addWidget(tools)

        split=QSplitter(Qt.Orientation.Vertical)
        table_frame=QFrame(); table_frame.setObjectName("card"); tlay=QVBoxLayout(table_frame)
        self.table=QTableWidget(0,8)
        self.table.setHorizontalHeaderLabels(["Holder","A/C No.","IFSC / ID","Bank","Branch","Type","Nickname","Active"])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(lambda _: self.edit_account())
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        tlay.addWidget(self.table)
        split.addWidget(table_frame)

        report=QFrame(); report.setObjectName("card"); rl=QHBoxLayout(report)
        rl.addWidget(QLabel("Reports & Export"))
        bankexp=QPushButton("Export Current View → Excel"); bankexp.clicked.connect(self.export_excel); rl.addWidget(bankexp)
        csv=QPushButton("Export Current View → CSV"); csv.clicked.connect(self.export_csv); rl.addWidget(csv)
        summary=QPushButton("Export Bank-wise Excel"); summary.clicked.connect(self.export_bankwise); rl.addWidget(summary)
        rl.addStretch()
        split.addWidget(report); split.setSizes([650,70])
        main.addWidget(split,1)

    def stat_card(self,label):
        f=QFrame(); f.setObjectName("card"); l=QVBoxLayout(f)
        a=QLabel(label); a.setObjectName("muted")
        b=QLabel("0"); b.setStyleSheet("font-size:22px;font-weight:700;color:#6f7cff;")
        l.addWidget(a); l.addWidget(b); f.value_label=b
        return f

    def menu(self):
        fm=self.menuBar().addMenu("File")
        for text,fn,key in [
            ("New Account",self.add_account,"Ctrl+N"),
            ("Open Database…",self.open_database,""),
            ("Export Excel…",self.export_excel,"Ctrl+E"),
            ("Export Bank-wise…",self.export_bankwise,"Ctrl+Shift+E"),
            ("Export CSV…",self.export_csv,""),
        ]:
            a=QAction(text,self)
            if key:a.setShortcut(QKeySequence(key))
            a.triggered.connect(fn); fm.addAction(a)
        fm.addSeparator()
        q=QAction("Quit",self); q.triggered.connect(self.close); fm.addAction(q)

    def visible_accounts(self):
        bank=self.bank_filter.currentText()
        accounts=self.db.list_accounts(self.search.text().strip())
        if bank!="All banks":
            accounts=[a for a in accounts if a.bank==bank]
        return accounts

    def refresh(self):
        accounts=self.visible_accounts()
        self.table.setRowCount(len(accounts))
        for r,a in enumerate(accounts):
            vals=[a.holder,a.account_no,a.ifsc,a.bank,a.branch,a.account_type,a.nickname,"Yes" if a.active else "No"]
            for c,v in enumerate(vals):
                item=QTableWidgetItem(str(v))
                if c in (1,2): item.setData(Qt.ItemDataRole.UserRole,a.id)
                self.table.setItem(r,c,item)
        self.table.resizeRowsToContents()

        all_accounts=self.db.list_accounts()
        banks=sorted(set(a.bank for a in all_accounts),key=str.casefold)
        current=self.bank_filter.currentText()
        self.bank_filter.blockSignals(True); self.bank_filter.clear(); self.bank_filter.addItem("All banks")
        self.bank_filter.addItems(banks)
        if current in ["All banks"]+banks:self.bank_filter.setCurrentText(current)
        self.bank_filter.blockSignals(False)

        self.stat_total.value_label.setText(str(len(all_accounts)))
        self.stat_banks.value_label.setText(str(len(banks)))
        self.stat_holders.value_label.setText(str(len(set(a.holder for a in all_accounts))))
        self.stat_active.value_label.setText(str(sum(bool(a.active) for a in all_accounts)))
        self.status.setText(f"{len(accounts)} account(s) shown")

    def selected_id(self):
        row=self.table.currentRow()
        if row<0:return None
        # Retrieve by matching account number/holder from current filtered list.
        accounts=self.visible_accounts()
        return accounts[row].id if row<len(accounts) else None

    def add_account(self):
        dlg=AccountDialog(self)
        if dlg.exec():
            try:self.db.add(dlg.get_account()); self.refresh()
            except Exception as e: QMessageBox.critical(self,"Could not add account",str(e))

    def edit_account(self):
        aid=self.selected_id()
        if not aid:return
        a=self.db.get(aid)
        dlg=AccountDialog(self,a)
        if dlg.exec():
            try:self.db.update(dlg.get_account()); self.refresh()
            except Exception as e: QMessageBox.critical(self,"Could not update account",str(e))

    def delete_account(self):
        aid=self.selected_id()
        if not aid:return
        a=self.db.get(aid)
        if QMessageBox.question(self,"Delete Account",
            f"Delete the account ending in {a.account_no[-4:]} for {a.holder}?") == QMessageBox.StandardButton.Yes:
            self.db.delete(aid); self.refresh()

    def export_excel(self):
        accounts=self.visible_accounts()
        if not accounts:return
        path,_=QFileDialog.getSaveFileName(self,"Export Excel","Bank_Accounts.xlsx","Excel (*.xlsx)")
        if path:
            export_xlsx(accounts,path,"Bank Account Register — Current View")
            self.status.setText(f"Exported {len(accounts)} account(s)")

    def export_bankwise(self):
        accounts=self.visible_accounts()
        if not accounts:return
        path,_=QFileDialog.getSaveFileName(self,"Export Bank-wise Excel","Bank_Wise_Accounts.xlsx","Excel (*.xlsx)")
        if path:
            export_xlsx(accounts,path,"Bank-wise Bank Account Register")
            self.status.setText("Bank-wise Excel exported")

    def export_csv(self):
        accounts=self.visible_accounts()
        if not accounts:return
        path,_=QFileDialog.getSaveFileName(self,"Export CSV","Bank_Accounts.csv","CSV (*.csv)")
        if path:
            export_csv(accounts,path); self.status.setText("CSV exported")

    def open_database(self):
        QMessageBox.information(self,"Local Database",
            f"Current database:\n{self.db.path}\n\nUse this local SQLite database for your account register.")

    def closeEvent(self,event):
        self.db.close(); event.accept()


def main():
    app=QApplication(sys.argv)
    app.setApplicationName("Bank Account Manager")
    app.setStyleSheet(STYLE)
    win=MainWindow(); win.show()
    sys.exit(app.exec())


if __name__=="__main__":
    main()
