
from PySide6.QtWidgets import (
    QDialog,QFormLayout,QLineEdit,QComboBox,QPlainTextEdit,QCheckBox,
    QDialogButtonBox,QMessageBox
)
from .models import Account


class AccountDialog(QDialog):
    def __init__(self,parent=None,account=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Account" if account else "New Bank Account")
        self.resize(500,520)
        self.account=account

        form=QFormLayout(self)
        self.holder=QLineEdit()
        self.account_no=QLineEdit()
        self.ifsc=QLineEdit()
        self.bank=QLineEdit()
        self.branch=QLineEdit()
        self.account_type=QComboBox()
        self.account_type.addItems(["Savings","Current","Deposit","Post Office","Other"])
        self.nickname=QLineEdit()
        self.notes=QPlainTextEdit()
        self.active=QCheckBox("Account is active")
        self.active.setChecked(True)

        for label,w in [
            ("Account Holder *",self.holder),("A/C No. *",self.account_no),
            ("IFSC / Identifier",self.ifsc),("Bank / Institution *",self.bank),
            ("Branch",self.branch),("Account Type",self.account_type),
            ("Nickname",self.nickname),("Notes",self.notes),("",self.active)
        ]:
            form.addRow(label,w)

        buttons=QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

        if account:
            self.load_account(account)

    def load_account(self,a):
        self.holder.setText(a.holder)
        self.account_no.setText(a.account_no)
        self.ifsc.setText(a.ifsc)
        self.bank.setText(a.bank)
        self.branch.setText(a.branch)
        self.account_type.setCurrentText(a.account_type)
        self.nickname.setText(a.nickname)
        self.notes.setPlainText(a.notes)
        self.active.setChecked(bool(a.active))

    def get_account(self):
        return Account(
            id=self.account.id if self.account else None,
            holder=self.holder.text().strip(),
            account_no=self.account_no.text().strip(),
            ifsc=self.ifsc.text().strip().upper(),
            bank=self.bank.text().strip(),
            branch=self.branch.text().strip(),
            account_type=self.account_type.currentText(),
            nickname=self.nickname.text().strip(),
            notes=self.notes.toPlainText().strip(),
            active=self.active.isChecked(),
        )

    def accept(self):
        a=self.get_account()
        if not a.holder or not a.account_no or not a.bank:
            QMessageBox.warning(self,"Required Fields",
                                "Account Holder, A/C No. and Bank are required.")
            return
        super().accept()
