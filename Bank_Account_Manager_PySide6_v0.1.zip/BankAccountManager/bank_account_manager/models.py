
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class Account:
    id: Optional[int] = None
    holder: str = ""
    account_no: str = ""
    ifsc: str = ""
    bank: str = ""
    branch: str = ""
    account_type: str = "Savings"
    nickname: str = ""
    notes: str = ""
    active: bool = True

    def to_dict(self):
        return asdict(self)
