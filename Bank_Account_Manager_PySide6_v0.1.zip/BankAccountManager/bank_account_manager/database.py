
import sqlite3
from pathlib import Path
from .models import Account

APP_DIR = Path.home() / ".bank_account_manager"
DB_PATH = APP_DIR / "bank_accounts.db"

INITIAL_DATA = [
    ("Sukhwinder Kaur", "02820110000720", "KKBK0004098", "KOTAK MAHINDRA BANK", "MOHALI - SECTOR 65"),
    ("Jasvir Singh", "1025000100135077", "PUNB0102500", "Punjab National Bank", "Kalanwali"),
    ("Jasvir Singh", "041010100025197", "UTIB0000041", "Axis Bank", "MOHALI - SECTOR 64"),
    ("Sukhwinder Kaur", "1025000100185984", "PUNB0102500", "Punjab National Bank", "Kalanwali"),
    ("Jasvir Singh", "1025008800016315", "PUNB0102500", "Punjab National Bank", "Kalanwali"),
    ("Jasvir Singh", "4676201303", "CIF383334675", "Post Office", "MOHALI - SECTOR 64"),
    ("Jasvir Singh & Sukhwinder Kaur", "200634001002310", "UTIB0SAS001", "MCCB", "MOHALI - SECTOR 64"),
    ("Sukhwinder Kaur", "02820110000720", "KKBK0004098", "KOTAK MAHINDRA BANK", "MOHALI - SECTOR 65"),
]


class Database:
    def __init__(self, path=DB_PATH):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.init_db()

    def init_db(self):
        self.conn.execute("""
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            holder TEXT NOT NULL,
            account_no TEXT NOT NULL,
            ifsc TEXT,
            bank TEXT NOT NULL,
            branch TEXT,
            account_type TEXT DEFAULT 'Savings',
            nickname TEXT,
            notes TEXT,
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)
        self.conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS ux_account_identity
        ON accounts(holder, account_no, bank)
        """)
        self.conn.commit()

        if self.conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0] == 0:
            self.conn.executemany("""
                INSERT INTO accounts(holder,account_no,ifsc,bank,branch)
                VALUES(?,?,?,?,?)
            """, INITIAL_DATA)
            self.conn.commit()

    def list_accounts(self, search=""):
        q = """
        SELECT * FROM accounts
        WHERE holder LIKE ? OR account_no LIKE ? OR ifsc LIKE ?
           OR bank LIKE ? OR branch LIKE ? OR nickname LIKE ?
        ORDER BY bank COLLATE NOCASE, holder COLLATE NOCASE, account_no
        """
        s = f"%{search}%"
        return [Account(**dict(r)) for r in self.conn.execute(q, (s,s,s,s,s,s)).fetchall()]

    def get(self, account_id):
        r = self.conn.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        return Account(**dict(r)) if r else None

    def add(self, a: Account):
        cur = self.conn.execute("""
            INSERT INTO accounts
            (holder,account_no,ifsc,bank,branch,account_type,nickname,notes,active)
            VALUES(?,?,?,?,?,?,?,?,?)
        """, (a.holder,a.account_no,a.ifsc,a.bank,a.branch,a.account_type,a.nickname,a.notes,int(a.active)))
        self.conn.commit()
        return cur.lastrowid

    def update(self, a: Account):
        self.conn.execute("""
            UPDATE accounts SET holder=?,account_no=?,ifsc=?,bank=?,branch=?,
            account_type=?,nickname=?,notes=?,active=?,updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, (a.holder,a.account_no,a.ifsc,a.bank,a.branch,a.account_type,
              a.nickname,a.notes,int(a.active),a.id))
        self.conn.commit()

    def delete(self, account_id):
        self.conn.execute("DELETE FROM accounts WHERE id=?", (account_id,))
        self.conn.commit()

    def banks(self):
        return [r[0] for r in self.conn.execute(
            "SELECT DISTINCT bank FROM accounts ORDER BY bank COLLATE NOCASE"
        ).fetchall()]

    def bank_summary(self):
        return self.conn.execute("""
            SELECT bank, COUNT(*) AS accounts,
                   COUNT(DISTINCT holder) AS holders,
                   COUNT(DISTINCT branch) AS branches
            FROM accounts
            GROUP BY bank
            ORDER BY bank COLLATE NOCASE
        """).fetchall()

    def close(self):
        self.conn.close()
