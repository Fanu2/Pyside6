# Bank Account Manager

A beautiful local PySide6 desktop application built around the supplied bank-account register.

## Features

### CRUD
- Create account
- Read/search accounts
- Update account
- Delete account
- Active/inactive status

### Account fields
- Account holder
- Account number
- IFSC / identifier
- Bank / institution
- Branch
- Account type
- Nickname
- Notes

### Organisation
- Outliner-style account table
- Search across all important fields
- Bank filter
- Dashboard counters
- Duplicate identity protection at database level

### Reporting
- Export current view to Excel
- Export current view to CSV
- Bank-wise Excel report with a separate summary sheet
- Long account numbers preserved as text

### Storage
- Local SQLite database
- Default database:
  `~/.bank_account_manager/bank_accounts.db`
- Initial data is seeded from the supplied register

## Windows

From the project root:

```powershell
python -m pip install -r requirements.txt
python -m bank_account_manager
```

Tests:

```powershell
python -m pytest
```

## Suggested next versions

v0.2: bank-wise dashboard and charts
v0.3: account documents/attachments
v0.4: recurring payment/deposit reminders
v0.5: encrypted database option and backup/restore
v0.6: richer Excel templates and PDF reports
